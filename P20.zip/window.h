#ifndef WINDOW_H
#define WINDOW_H


class window
{
public:
    window();
};

#endif // WINDOW_H
