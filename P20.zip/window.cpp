#include "window.h"

window::window()
{

}
