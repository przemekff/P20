#include <sharedPins.h>

bool sharedPins[24];
