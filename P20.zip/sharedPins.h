#ifndef SHAREDPINS_H
#define SHAREDPINS_H

extern bool sharedPins[24];

#endif // SHAREDPINS_H
